<?php

if (! defined('ABSPATH')) {
	return;
}

// Ensure Blocksy is active and the extension function exists
if (! function_exists('blocksy_companion_get_ext')) {
	return;
}

$ext = blocksy_companion_get_ext('woocommerce-extra');
if (!$ext || !method_exists($ext, 'get_compare')) {
	return;
}

$compare_list = $ext->get_compare()->get_current_compare_list();

// Visibility classes
$visiblity_class = '';
if (function_exists('blocksy_visibility_classes') && function_exists('blocksy_companion_theme_functions')) {
	$visiblity_class = blocksy_visibility_classes(
		blocksy_companion_theme_functions()->blocksy_get_theme_mod(
			'product_compare_bar_visibility',
			[
				'desktop' => true,
				'tablet' => true,
				'mobile' => true,
			]
		)
	);
}

// Generate the Compare Bar HTML.
$max_slots = 2;
$slots_html = '';

$compare_items = array_values($compare_list);

for ($i = 0; $i < $max_slots; $i++) {
	$product = isset($compare_items[$i]) ? wc_get_product($compare_items[$i]['id']) : null;
	
	if ($product) {
		// Slot filled with product
		$thumbnail = $product->get_image('thumbnail');
		if (function_exists('blocksy_media') && get_post_thumbnail_id($product->get_id())) {
			$maybe_thumbnail = blocksy_media([
				'attachment_id' => get_post_thumbnail_id($product->get_id()),
				'post_id' => $product->get_id(),
				'ratio' => '1',
				'size' => 'thumbnail',
				'tag_name' => 'figure',
			]);
			if ($maybe_thumbnail) {
				$thumbnail = $maybe_thumbnail;
			}
		}

		$title = $ext->utils->get_formatted_title($product->get_id());
		$price = $product->get_price_html();

		// Modern Trash Icon (SVG)
		$remove_icon = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash-2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>';
		
		$remove_btn = '<a href="#" class="ct-compare-remove custom-compare-remove-btn" data-product_id="' . esc_attr($product->get_id()) . '" title="' . esc_attr__('Remove Product', 'blocksy-companion') . '">' . $remove_icon . '</a>';

		$slot_content = '<div class="custom-compare-slot filled-slot">';
		$slot_content .= '<div class="slot-header"><span class="slot-title">' . $title . '</span>' . $remove_btn . '</div>';
		$slot_content .= '<div class="slot-body">' . $thumbnail . '<div class="slot-price">' . $price . '</div></div>';
		$slot_content .= '</div>';
	} else {
		// Empty slot with search
		$slot_content = '<div class="custom-compare-slot empty-slot">';
		$slot_content .= '<div class="custom-compare-search-wrapper">';
		$slot_content .= '<input type="text" class="custom-compare-search-input" placeholder="Search product to compare..." autocomplete="off">';
		$slot_content .= '<div class="custom-compare-search-results"></div>';
		$slot_content .= '</div>';
		$slot_content .= '</div>';
	}

	$slots_html .= '<li class="compare-slot-item">' . $slot_content . '</li>';
}

// Compare Button
$button = '';
if (function_exists('blocksy_action_button') && function_exists('blocksy_companion_theme_functions')) {
	$icon = blocksy_companion_get_icon([
		'icon_descriptor' => blocksy_companion_theme_functions()->blocksy_get_theme_mod(
			'product_compare_bar_button_icon',
			[
				'icon' => 'blc blc-compare',
			]
		),
		'icon_container' => false,
	]);

	$url = '#ct-compare-modal';
	$maybe_page_id = blocksy_companion_theme_functions()->blocksy_get_theme_mod('woocommerce_compare_page');
	if (!empty($maybe_page_id)) {
		$maybe_permalink = get_permalink($maybe_page_id);
		if ($maybe_permalink) {
			$url = $maybe_permalink;
		}
	}

	$compare_label = blocksy_companion_theme_functions()->blocksy_get_theme_mod(
		'product_compare_bar_button_label',
		__('Compare Products', 'blocksy-companion')
	);

	$button = blocksy_action_button([
		'button_html_attributes' => [
			'href' => $url,
			'class' => 'ct-button custom-compare-main-btn',
			'aria-label' => $compare_label,
			'data-behaviour' => blocksy_companion_theme_functions()->blocksy_get_theme_mod('compare_table_placement', 'modal'),
		],
		'icon' => $icon,
		'content' => '<span class="ct-hidden-md ct-hidden-sm">' . $compare_label . '</span>'
	]);
}

$content = '<div class="ct-container custom-compare-container"><ul>' . $slots_html . '</ul>' . $button . '</div>';

$attr = [
	'class' => trim('ct-compare-bar custom-compare-bar-override ' . $visiblity_class)
];

if (function_exists('is_customize_preview') && is_customize_preview()) {
	$attr['data-shortcut'] = 'border:outside';
	$attr['data-shortcut-location'] = 'woocommerce_general:has_compare_panel';
}

if (function_exists('blocksy_html_tag_e')) {
	blocksy_html_tag_e('div', $attr, $content);
} else {
	// Fallback if blocksy function is missing
	echo '<div class="' . esc_attr($attr['class']) . '">' . $content . '</div>';
}
